# Lord-Of-The-Rings-FanSite-API
LoTR Fan Site built with Python and Flask using the API: https://the-one-api.dev/.

<p style="text-align:center;">Home Page.</p>

![home](https://i.postimg.cc/Cx9xqVhg/Home.png)

<br>
<p style="text-align:center;">Books Page.</p>

![books](https://github.com/Oviderzen/Lord-Of-The-Rings-FanSite-API/assets/130290407/e6f10061-e8ca-4520-b134-cf125174f7f2)



<br>
<p style="text-align:center;">Movies Page.</p
  
![movies](https://github.com/Oviderzen/Lord-Of-The-Rings-FanSite-API/assets/130290407/60c6797c-ce1d-475c-988f-0bde4cb7e6ec)



<br>
<p style="text-align:center;">Random Character.</p
  
![char](https://github.com/Oviderzen/Lord-Of-The-Rings-FanSite-API/assets/130290407/622c8c92-ae4c-4f7e-ad09-7bdd6210fb80)



<br>
<p style="text-align:center;">Random Quote.</p
  
![quote](https://github.com/Oviderzen/Lord-Of-The-Rings-FanSite-API/assets/130290407/c0109115-a3a3-4a19-826b-9ba0d2433f55)


